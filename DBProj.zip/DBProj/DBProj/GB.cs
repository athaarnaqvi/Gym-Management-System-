﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace DBProj
{
    public static class GB
    {
        //login and registration form
        public static string T_un;
        public static string T_pass;
        public static string T_fname;
        public static string T_lname;
        public static string T_gender;
        public static string T_email;
        public static string T_dob;
        public static string T_qualification;
        public static string T_specialityarea;
        public static string T_experience;
        public static string T_status;
        public static string T_gym;
        public static int T_gymid;
    }
}
