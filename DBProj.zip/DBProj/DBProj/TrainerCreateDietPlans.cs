﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProj
{
    public partial class TrainerCreateDietPlans : Form
    {
        public TrainerCreateDietPlans()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)  //purpose
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) //type
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)  //no of meals
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)  //meal
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)  //proteins
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)  //carbs
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)  //fats
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)  //fibres
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)  //potential allergies
        {

        }

        private void button2_Click(object sender, EventArgs e)  //back button
        {
            this.Hide();

            Trainer mainPage = new Trainer();
            mainPage.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)  //enter button
        {
            this.Hide();

            TrainerCreateDietPlans dietform = new TrainerCreateDietPlans();
            dietform.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)  //create diet button
        {
            this.Hide();

            Trainer mainPage = new Trainer();
            mainPage.ShowDialog();
        }
    }
}
