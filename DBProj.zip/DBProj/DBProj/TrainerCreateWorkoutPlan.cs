﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProj
{
    public partial class TrainerCreateWorkoutPlan : Form
    {
        public TrainerCreateWorkoutPlan()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)  //goal
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)  //experience
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)  //exercise
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)  //machine
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)  //sets
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)  //reps
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)  //rest interval
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)  //muscle target
        {

        }

        private void button2_Click(object sender, EventArgs e)  //backbutton
        {
            this.Hide();

            Trainer mainPage = new Trainer();
            mainPage.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)  //enter button
        {
            this.Hide();

            TrainerCreateWorkoutPlan workoutform = new TrainerCreateWorkoutPlan();
            workoutform.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)   //create wokrout plan button
        {
            this.Hide();

            Trainer mainPage = new Trainer();
            mainPage.ShowDialog();
        }
    }
}
